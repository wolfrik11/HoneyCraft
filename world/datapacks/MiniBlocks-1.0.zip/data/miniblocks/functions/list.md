* bedrock
* dirt
* grass
* stone
* cobblestone
* mossy cobblestone
* granite
* polished granite
* diorite
* polished diorite
* andesite
* polished andesite
* deepslate
* polished deepslate
* cobbled deepslate
* deepslate tiles
* chiseled deepslate
* calcite
* tuff
* dripstone block
* coarse dirt
* podzol
* rooted dirt
* mycelium
* moss block
* brown mushroom block
* red mushroom block
* mushroom stem
* melon
* pumpkin
* craved pumpkin
* jack o'lantern
* hay bale
* ice
* packed ice
* blue ice
* powder snow
* snow grass
* clay
* dried kelp block
* sand
* red sand
* gravel
* sponge
* wet sponge
* sandstone
* red sandstone
* cut sandstone
* chiseled sandstone
* chiseled red sandstone
* cut red sandstone
* stone bricks
* mossy stone bricks
* cracked stone bricks
* deepslate bricks
* prismarine
* prismarine bricks
* dark prismarine
* sea lantern
* netherrack
* nether bricks
* cracked nether bricks
* netherite block
* nether gold ore
* nether quartz ore
* nether wart block
* warped wart block
* red nether bricks
* crimson nylium
* warped nylium
* ancient debris
* quartz block
* quartz pillar
* quartz bricks
* chiseled quartz
* magma block
* shroomlight
* blackstone
* polished blackstone
* gilded blackstone
* polished blackstone bricks
* lodestone
* respawn anchor
* respawn anchor_full
* crying obsidian
* soul sand
* soul soil
* basalt
* polished basalt
* smooth basalt
* glowstone
* endstone
* endstone bricks
* purpur block
* purpur pillar
* redstone block
* piston
* sticky piston
* slime block
* honey block
* observer
* dropper
* target block
* chest
* furnace
* furnace_burning
* redstone lamp
* redstone lamp_powered
* note block
* jukebox
* loom
* barrel
* smoker
* smoker_burning
* blast furnace
* blast furnace_burning
* cartography table
* fletching table
* smithing table
* crafting table
* end crystal
* command block
* structure block
* coal ore
* deepslate coal ore
* iron ore
* deepslate iron ore
* copper ore
* deepslate copper ore
* gold ore
* deepsalte gold ore
* redstone ore
* deepsalte redstone ore
* emerald ore
* deepslate emerald ore
* lapis lazuli ore
* deepsalte lapis lazuli ore
* diamond ore
* deepsalte diamond ore
* block of coal
* block of raw iron
* block of raw gold
* block of raw copper
* block of amethyst
* block of iron
* block of copper
* block of gold
* block of diamond
* block of netherite
* exposed copper
* weathered copper
* oxidized copper
* cut copper
* exposed cut copper
* weathered cut copper
* oxidized cut copper
* block of lapis lazuli
* block of emerald
* ender chest
* beacon
* oak log
* spruce log
* dark oak log
* jungle log
* acacia log
* birch log
* stripped oak log
* stripped spruce log
* stripped dark oak log
* stripped jungle log
* stripped acacia log
* stripped birch log
* crimson stem
* warped stem
* stripped crimson stem
* stripped waped stem
* glazed terracota black
* glazed terracota blue
* glazed terracota brown
* glazed terracota cyan
* glazed terracota gray
* glazed terracota green
* glazed terracota light blue
* glazed terracota light gra
* glazed terracota lime
* glazed terracota magenta
* glazed terracota orange
* glazed terracota pink
* glazed terracota purple
* glazed terracota red
* glazed terracota white
* glazed terracota yellow